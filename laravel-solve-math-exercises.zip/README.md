## laravel solve math exercises

### Install: (Run in Terminal)
```bash
composer install 	
# or: composer install --ignore-platform-reqs
# or: composer update 
# or: composer update --ignore-platform-reqs 
cp .env.example .env
create database: laravel-solve-math-excercises  # utf8_unicode_ci
php artisan migrate:fresh --seed
php artisan key:generate
php artisan serve
```

## Dev: Phan Văn Bằng
###### Facebook: fb.com/it0902
###### Github: github.com/ilyouu
###### Email: pvbang23092002@gmail.com
