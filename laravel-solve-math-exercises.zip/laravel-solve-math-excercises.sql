-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2022 at 11:10 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel-solve-math-excercises`
--

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

CREATE TABLE `chapters` (
  `id_chapter` int(10) UNSIGNED NOT NULL,
  `id_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_chapter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`id_chapter`, `id_subject`, `name_chapter`, `slug`, `created_at`, `updated_at`) VALUES
(1, '1', 'Chương I. Ôn tập và bổ sung', 'chuong-i-on-tap-va-bo-sung', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(2, '2', 'Chương I. Ôn tập và bổ sung', 'chuong-i-on-tap-va-bo-sung', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(3, '1', 'Chương II. Phép cộng có nhớ trong phạm vi 100', 'chuong-ii-phep-cong-co-nho-trong-pham-vi-100', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(4, '2', 'Chương II. Phép cộng có nhớ trong phạm vi 100', 'chuong-ii-phep-cong-co-nho-trong-pham-vi-100', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(5, '1', 'Chương III. Phép trừ có nhớ trong phạm vi 100', 'chuong-iii-phep-tru-co-nho-trong-pham-vi-100', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(6, '2', 'Chương III. Phép trừ có nhớ trong phạm vi 100', 'chuong-iii-phep-tru-co-nho-trong-pham-vi-100', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(7, '1', 'Chương IV. Ôn Tập', 'chuong-iv-on-tap', '2022-07-06 23:31:58', '2022-07-06 23:31:58'),
(8, '2', 'Chương IV. Ôn Tập', 'chuong-iv-on-tap', '2022-07-06 23:31:58', '2022-07-06 23:31:58'),
(9, '1', 'Chương V. Phép nhân và phép chia', 'chuong-v-phep-nhan-va-phep-chia', '2022-07-06 23:33:12', '2022-07-06 23:33:12'),
(10, '2', 'Chương V. Phép nhân và phép chia', 'chuong-v-phep-nhan-va-phep-chia', '2022-07-06 23:33:12', '2022-07-06 23:33:12'),
(11, '1', 'Chương VI. Các số trong phạm vi 1000', 'chuong-vi-cac-so-trong-pham-vi-1000', '2022-07-06 23:34:11', '2022-07-06 23:34:11'),
(12, '2', 'Chương VI. Các số trong phạm vi 1000', 'chuong-vi-cac-so-trong-pham-vi-1000', '2022-07-06 23:34:11', '2022-07-06 23:34:11'),
(13, '1', 'Chương VII. Ôn tập cuối năm học', 'chuong-vii-on-tap-cuoi-nam-hoc', '2022-07-06 23:34:34', '2022-07-06 23:34:34'),
(14, '2', 'Chương VII. Ôn tập cuối năm học', 'chuong-vii-on-tap-cuoi-nam-hoc', '2022-07-06 23:34:34', '2022-07-06 23:34:34'),
(15, '3', 'Chương I. Ôn tập và bổ sung', 'chuong-i-on-tap-va-bo-sung', '2022-07-06 23:35:08', '2022-07-06 23:35:08'),
(16, '4', 'Chương I. Ôn tập và bổ sung', 'chuong-i-on-tap-va-bo-sung', '2022-07-06 23:35:08', '2022-07-06 23:35:08'),
(17, '3', 'Chương II. Phép nhân và phép chia trong phạm vi 1000', 'chuong-ii-phep-nhan-va-phep-chia-trong-pham-vi-1000', '2022-07-06 23:35:29', '2022-07-06 23:35:29'),
(18, '4', 'Chương II. Phép nhân và phép chia trong phạm vi 1000', 'chuong-ii-phep-nhan-va-phep-chia-trong-pham-vi-1000', '2022-07-06 23:35:29', '2022-07-06 23:35:29'),
(19, '3', 'Chương III. Các số đến 10000', 'chuong-iii-cac-so-den-10000', '2022-07-06 23:35:46', '2022-07-06 23:35:46'),
(20, '4', 'Chương III. Các số đến 10000', 'chuong-iii-cac-so-den-10000', '2022-07-06 23:35:46', '2022-07-06 23:35:46'),
(21, '3', 'Chương IV. Các số đến 100000', 'chuong-iv-cac-so-den-100000', '2022-07-06 23:36:11', '2022-07-06 23:36:11'),
(22, '4', 'Chương IV. Các số đến 100000', 'chuong-iv-cac-so-den-100000', '2022-07-06 23:36:11', '2022-07-06 23:36:11'),
(23, '3', 'Chương V. Ôn tập cuối năm', 'chuong-v-on-tap-cuoi-nam', '2022-07-06 23:36:46', '2022-07-06 23:36:46'),
(24, '4', 'Chương V. Ôn tập cuối năm', 'chuong-v-on-tap-cuoi-nam', '2022-07-06 23:36:46', '2022-07-06 23:36:46'),
(25, '5', 'Chương I. Số tự nhiên. Bảng đơn vị đo khối lượng', 'chuong-i-so-tu-nhien-bang-don-vi-do-khoi-luong', '2022-07-06 23:37:30', '2022-07-06 23:37:30'),
(26, '6', 'Chương I. Số tự nhiên. Bảng đơn vị đo khối lượng', 'chuong-i-so-tu-nhien-bang-don-vi-do-khoi-luong', '2022-07-06 23:37:30', '2022-07-06 23:37:30'),
(27, '5', 'Chương II. Bốn phép tính với các số tự nhiên. Hình học', 'chuong-ii-bon-phep-tinh-voi-cac-so-tu-nhien-hinh-hoc', '2022-07-06 23:37:59', '2022-07-06 23:37:59'),
(28, '6', 'Chương II. Bốn phép tính với các số tự nhiên. Hình học', 'chuong-ii-bon-phep-tinh-voi-cac-so-tu-nhien-hinh-hoc', '2022-07-06 23:37:59', '2022-07-06 23:37:59'),
(29, '5', 'Chương III. Dấu hiệu chia hết cho 2,5,9,3. Giới thiệu hình bình hành', 'chuong-iii-dau-hieu-chia-het-cho-2593-gioi-thieu-hinh-binh-hanh', '2022-07-06 23:50:14', '2022-07-06 23:50:14'),
(30, '6', 'Chương III. Dấu hiệu chia hết cho 2,5,9,3. Giới thiệu hình bình hành', 'chuong-iii-dau-hieu-chia-het-cho-2593-gioi-thieu-hinh-binh-hanh', '2022-07-06 23:50:14', '2022-07-06 23:50:14'),
(31, '5', 'Chương IV. Phân số - Các phép tính với phân số. Giới thiệu hình thoi', 'chuong-iv-phan-so-cac-phep-tinh-voi-phan-so-gioi-thieu-hinh-thoi', '2022-07-06 23:50:49', '2022-07-06 23:50:49'),
(32, '6', 'Chương IV. Phân số - Các phép tính với phân số. Giới thiệu hình thoi', 'chuong-iv-phan-so-cac-phep-tinh-voi-phan-so-gioi-thieu-hinh-thoi', '2022-07-06 23:50:49', '2022-07-06 23:50:49'),
(33, '5', 'Chương V. Tỉ số - Một số bài toán liên quan đến tỉ số. Tỉ lệ bản đồ', 'chuong-v-ti-so-mot-so-bai-toan-lien-quan-den-ti-so-ti-le-ban-do', '2022-07-06 23:51:29', '2022-07-06 23:51:29'),
(34, '6', 'Chương V. Tỉ số - Một số bài toán liên quan đến tỉ số. Tỉ lệ bản đồ', 'chuong-v-ti-so-mot-so-bai-toan-lien-quan-den-ti-so-ti-le-ban-do', '2022-07-06 23:51:29', '2022-07-06 23:51:29'),
(35, '5', 'Chương VI. Ôn  tập', 'chuong-vi-on-tap', '2022-07-06 23:51:41', '2022-07-06 23:51:41'),
(36, '6', 'Chương VI. Ôn  tập', 'chuong-vi-on-tap', '2022-07-06 23:51:41', '2022-07-06 23:51:41'),
(37, '7', 'Chương I. Ôn tập và bổ sung về phân số. Giải toán liên quan đến tỉ lệ. Bảng đơn vị đo diện tích', 'chuong-i-on-tap-va-bo-sung-ve-phan-so-giai-toan-lien-quan-den-ti-le-bang-don-vi-do-dien-tich', '2022-07-06 23:52:39', '2022-07-06 23:52:39'),
(38, '8', 'Chương I. Ôn tập và bổ sung về phân số. Giải toán liên quan đến tỉ lệ. Bảng đơn vị đo diện tích', 'chuong-i-on-tap-va-bo-sung-ve-phan-so-giai-toan-lien-quan-den-ti-le-bang-don-vi-do-dien-tich', '2022-07-06 23:52:39', '2022-07-06 23:52:39'),
(39, '7', 'Chương II. Số thập phân. Các phép tính với số thập phân', 'chuong-ii-so-thap-phan-cac-phep-tinh-voi-so-thap-phan', '2022-07-06 23:53:11', '2022-07-06 23:53:11'),
(40, '8', 'Chương II. Số thập phân. Các phép tính với số thập phân', 'chuong-ii-so-thap-phan-cac-phep-tinh-voi-so-thap-phan', '2022-07-06 23:53:11', '2022-07-06 23:53:11'),
(41, '7', 'Chương III. Hình học', 'chuong-iii-hinh-hoc', '2022-07-06 23:53:31', '2022-07-06 23:53:31'),
(42, '8', 'Chương III. Hình học', 'chuong-iii-hinh-hoc', '2022-07-06 23:53:31', '2022-07-06 23:53:31'),
(43, '7', 'Chương IV. Số đo thời gian. Chuyển động đều', 'chuong-iv-so-do-thoi-gian-chuyen-dong-deu', '2022-07-06 23:54:50', '2022-07-06 23:54:50'),
(44, '8', 'Chương IV. Số đo thời gian. Chuyển động đều', 'chuong-iv-so-do-thoi-gian-chuyen-dong-deu', '2022-07-06 23:54:50', '2022-07-06 23:54:50'),
(45, '7', 'Chương V. Ôn tập', 'chuong-v-on-tap', '2022-07-06 23:55:11', '2022-07-06 23:55:11'),
(46, '8', 'Chương V. Ôn tập', 'chuong-v-on-tap', '2022-07-06 23:55:11', '2022-07-06 23:55:11'),
(47, '9', 'Chương I. Ôn tập và bổ túc số tự nhiên', 'chuong-i-on-tap-va-bo-tuc-so-tu-nhien', '2022-07-07 00:20:21', '2022-07-07 00:20:21'),
(48, '10', 'Chương I. Ôn tập và bổ túc số tự nhiên', 'chuong-i-on-tap-va-bo-tuc-so-tu-nhien', '2022-07-07 00:20:21', '2022-07-07 00:20:21'),
(49, '9', 'Chương II. Số Nguyên', 'chuong-ii-so-nguyen', '2022-07-07 00:20:40', '2022-07-07 00:20:40'),
(50, '10', 'Chương II. Số Nguyên', 'chuong-ii-so-nguyen', '2022-07-07 00:20:40', '2022-07-07 00:20:40'),
(51, '11', 'Chương I. Đoạn thẳng', 'chuong-i-doan-thang', '2022-07-07 00:21:39', '2022-07-07 00:21:39'),
(52, '12', 'Chương I. Đoạn thẳng', 'chuong-i-doan-thang', '2022-07-07 00:21:39', '2022-07-07 00:21:39'),
(53, '11', 'Chương II. Góc', 'chuong-ii-goc', '2022-07-07 00:21:53', '2022-07-07 00:21:53'),
(54, '12', 'Chương II. Góc', 'chuong-ii-goc', '2022-07-07 00:21:53', '2022-07-07 00:21:53'),
(55, '11', 'Chương III. Phân số', 'chuong-iii-phan-so', '2022-07-07 00:22:15', '2022-07-07 00:22:15'),
(56, '12', 'Chương III. Phân số', 'chuong-iii-phan-so', '2022-07-07 00:22:15', '2022-07-07 00:22:15'),
(57, '13', 'Chương I. Số hữu tỉ. Số thực', 'chuong-i-so-huu-ti-so-thuc', '2022-07-07 00:22:55', '2022-07-07 00:22:55'),
(58, '14', 'Chương I. Số hữu tỉ. Số thực', 'chuong-i-so-huu-ti-so-thuc', '2022-07-07 00:22:55', '2022-07-07 00:22:55'),
(59, '13', 'Chương II. Hàm số và đồ thị', 'chuong-ii-ham-so-va-do-thi', '2022-07-07 00:23:16', '2022-07-07 00:23:16'),
(60, '14', 'Chương II. Hàm số và đồ thị', 'chuong-ii-ham-so-va-do-thi', '2022-07-07 00:23:16', '2022-07-07 00:23:16'),
(61, '15', 'Chương I. Đường thẳng vuông góc, Đường thẳng song song', 'chuong-i-duong-thang-vuong-goc-duong-thang-song-song', '2022-07-07 00:23:43', '2022-07-07 00:23:43'),
(62, '16', 'Chương I. Đường thẳng vuông góc, Đường thẳng song song', 'chuong-i-duong-thang-vuong-goc-duong-thang-song-song', '2022-07-07 00:23:43', '2022-07-07 00:23:43'),
(63, '15', 'Chương II. Tam giác', 'chuong-ii-tam-giac', '2022-07-07 00:24:21', '2022-07-07 00:24:21'),
(64, '16', 'Chương II. Tam giác', 'chuong-ii-tam-giac', '2022-07-07 00:24:21', '2022-07-07 00:24:21'),
(65, '13', 'Chương III. Thống kê', 'chuong-iii-thong-ke', '2022-07-07 00:24:37', '2022-07-07 00:24:37'),
(66, '14', 'Chương III. Thống kê', 'chuong-iii-thong-ke', '2022-07-07 00:24:37', '2022-07-07 00:24:37'),
(67, '13', 'Chương IV. Biểu thức đại số', 'chuong-iv-bieu-thuc-dai-so', '2022-07-07 00:25:12', '2022-07-07 00:25:12'),
(68, '14', 'Chương IV. Biểu thức đại số', 'chuong-iv-bieu-thuc-dai-so', '2022-07-07 00:25:12', '2022-07-07 00:25:12'),
(69, '15', 'Chương III. Quan hệ giữa các yếu tố trong tam giác. Các đường đồng quy của tam giác', 'chuong-iii-quan-he-giua-cac-yeu-to-trong-tam-giac-cac-duong-dong-quy-cua-tam-giac', '2022-07-07 00:29:35', '2022-07-07 00:29:35'),
(70, '16', 'Chương III. Quan hệ giữa các yếu tố trong tam giác. Các đường đồng quy của tam giác', 'chuong-iii-quan-he-giua-cac-yeu-to-trong-tam-giac-cac-duong-dong-quy-cua-tam-giac', '2022-07-07 00:29:35', '2022-07-07 00:29:35'),
(71, '17', 'Chương I. Phép nhân và phép chia đa thức', 'chuong-i-phep-nhan-va-phep-chia-da-thuc', '2022-07-07 00:32:45', '2022-07-07 00:32:45'),
(72, '18', 'Chương I. Phép nhân và phép chia đa thức', 'chuong-i-phep-nhan-va-phep-chia-da-thuc', '2022-07-07 00:32:45', '2022-07-07 00:32:45'),
(73, '17', 'Chương II. Phân thức đại số', 'chuong-ii-phan-thuc-dai-so', '2022-07-07 00:33:25', '2022-07-07 00:33:25'),
(74, '18', 'Chương II. Phân thức đại số', 'chuong-ii-phan-thuc-dai-so', '2022-07-07 00:33:25', '2022-07-07 00:33:25'),
(75, '17', 'Chương III. Phương trình bật nhất một ẩn', 'chuong-iii-phuong-trinh-bat-nhat-mot-an', '2022-07-07 00:34:03', '2022-07-07 00:34:03'),
(76, '18', 'Chương III. Phương trình bật nhất một ẩn', 'chuong-iii-phuong-trinh-bat-nhat-mot-an', '2022-07-07 00:34:03', '2022-07-07 00:34:03'),
(77, '17', 'Chương IV. Bất phương trình bậc nhất một ẩn', 'chuong-iv-bat-phuong-trinh-bac-nhat-mot-an', '2022-07-07 00:34:42', '2022-07-07 00:34:42'),
(78, '18', 'Chương IV. Bất phương trình bậc nhất một ẩn', 'chuong-iv-bat-phuong-trinh-bac-nhat-mot-an', '2022-07-07 00:34:42', '2022-07-07 00:34:42'),
(79, '18', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:35:10', '2022-07-07 00:35:10'),
(80, '19', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:35:10', '2022-07-07 00:35:10'),
(81, '19', 'Chương I. Tứ giác', 'chuong-i-tu-giac', '2022-07-07 00:35:58', '2022-07-07 00:35:58'),
(82, '20', 'Chương I. Tứ giác', 'chuong-i-tu-giac', '2022-07-07 00:35:58', '2022-07-07 00:35:58'),
(83, '19', 'Chương II. Đa giác. Diện tích đa giác', 'chuong-ii-da-giac-dien-tich-da-giac', '2022-07-07 00:36:28', '2022-07-07 00:36:28'),
(84, '20', 'Chương II. Đa giác. Diện tích đa giác', 'chuong-ii-da-giac-dien-tich-da-giac', '2022-07-07 00:36:28', '2022-07-07 00:36:28'),
(85, '19', 'Chương III. Tam giác đồng dạng', 'chuong-iii-tam-giac-dong-dang', '2022-07-07 00:36:47', '2022-07-07 00:36:47'),
(86, '20', 'Chương III. Tam giác đồng dạng', 'chuong-iii-tam-giac-dong-dang', '2022-07-07 00:36:47', '2022-07-07 00:36:47'),
(87, '19', 'Chương IV. Hình lăng trụ đứng. Hình chóp đều', 'chuong-iv-hinh-lang-tru-dung-hinh-chop-deu', '2022-07-07 00:37:09', '2022-07-07 00:37:09'),
(88, '20', 'Chương IV. Hình lăng trụ đứng. Hình chóp đều', 'chuong-iv-hinh-lang-tru-dung-hinh-chop-deu', '2022-07-07 00:37:09', '2022-07-07 00:37:09'),
(89, '19', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:37:19', '2022-07-07 00:37:19'),
(90, '20', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:37:19', '2022-07-07 00:37:19'),
(91, '21', 'Chương I. Căn bậc hai. Căn bậc ba', 'chuong-i-can-bac-hai-can-bac-ba', '2022-07-07 00:37:52', '2022-07-07 00:37:52'),
(92, '22', 'Chương I. Căn bậc hai. Căn bậc ba', 'chuong-i-can-bac-hai-can-bac-ba', '2022-07-07 00:37:52', '2022-07-07 00:37:52'),
(93, '21', 'Chương II. Hàm số bậc nhất', 'chuong-ii-ham-so-bac-nhat', '2022-07-07 00:38:16', '2022-07-07 00:38:16'),
(94, '22', 'Chương II. Hàm số bậc nhất', 'chuong-ii-ham-so-bac-nhat', '2022-07-07 00:38:16', '2022-07-07 00:38:16'),
(95, '21', 'Chương III. Hệ hai phương trình bậc nhất hai ẩn', 'chuong-iii-he-hai-phuong-trinh-bac-nhat-hai-an', '2022-07-07 00:38:34', '2022-07-07 00:38:34'),
(96, '22', 'Chương III. Hệ hai phương trình bậc nhất hai ẩn', 'chuong-iii-he-hai-phuong-trinh-bac-nhat-hai-an', '2022-07-07 00:38:34', '2022-07-07 00:38:34'),
(97, '21', 'Chương IV. Hàm số y = ax^2 (a ≠ 0). Phương trình bậc hai một ẩn', 'chuong-iv-ham-so-y-ax2-a-0-phuong-trinh-bac-hai-mot-an', '2022-07-07 00:42:33', '2022-07-07 00:42:33'),
(98, '22', 'Chương IV. Hàm số y = ax^2 (a ≠ 0). Phương trình bậc hai một ẩn', 'chuong-iv-ham-so-y-ax2-a-0-phuong-trinh-bac-hai-mot-an', '2022-07-07 00:42:33', '2022-07-07 00:42:33'),
(99, '23', 'Chương I. Hệ thức lượng trong tam giác vuông', 'chuong-i-he-thuc-luong-trong-tam-giac-vuong', '2022-07-07 00:43:03', '2022-07-07 00:43:03'),
(100, '24', 'Chương I. Hệ thức lượng trong tam giác vuông', 'chuong-i-he-thuc-luong-trong-tam-giac-vuong', '2022-07-07 00:43:03', '2022-07-07 00:43:03'),
(101, '23', 'Chương II. Đường tròn', 'chuong-ii-duong-tron', '2022-07-07 00:43:14', '2022-07-07 00:43:14'),
(102, '24', 'Chương II. Đường tròn', 'chuong-ii-duong-tron', '2022-07-07 00:43:14', '2022-07-07 00:43:14'),
(103, '23', 'Chương III. Góc với đường tròn', 'chuong-iii-goc-voi-duong-tron', '2022-07-07 00:43:28', '2022-07-07 00:43:28'),
(104, '24', 'Chương III. Góc với đường tròn', 'chuong-iii-goc-voi-duong-tron', '2022-07-07 00:43:28', '2022-07-07 00:43:28'),
(105, '23', 'Chương IV. Hình trụ - Hình nón - Hình Cầu', 'chuong-iv-hinh-tru-hinh-non-hinh-cau', '2022-07-07 00:43:52', '2022-07-07 00:43:52'),
(106, '24', 'Chương IV. Hình trụ - Hình nón - Hình Cầu', 'chuong-iv-hinh-tru-hinh-non-hinh-cau', '2022-07-07 00:43:52', '2022-07-07 00:43:52'),
(107, '25', 'Chương I. Mệnh đề. Tập hợp', 'chuong-i-menh-de-tap-hop', '2022-07-07 00:44:44', '2022-07-07 00:44:44'),
(108, '26', 'Chương I. Mệnh đề. Tập hợp', 'chuong-i-menh-de-tap-hop', '2022-07-07 00:44:44', '2022-07-07 00:44:44'),
(109, '25', 'Chương II. Hàm số bậc nhất và bậc hai', 'chuong-ii-ham-so-bac-nhat-va-bac-hai', '2022-07-07 00:45:02', '2022-07-07 00:45:02'),
(110, '26', 'Chương II. Hàm số bậc nhất và bậc hai', 'chuong-ii-ham-so-bac-nhat-va-bac-hai', '2022-07-07 00:45:02', '2022-07-07 00:45:02'),
(111, '25', 'Chương III. Phương trình. Hệ phương trình', 'chuong-iii-phuong-trinh-he-phuong-trinh', '2022-07-07 00:45:17', '2022-07-07 00:45:17'),
(112, '26', 'Chương III. Phương trình. Hệ phương trình', 'chuong-iii-phuong-trinh-he-phuong-trinh', '2022-07-07 00:45:17', '2022-07-07 00:45:17'),
(113, '25', 'Chương IV. Bất đẳng thức. Bất phương trình', 'chuong-iv-bat-dang-thuc-bat-phuong-trinh', '2022-07-07 00:45:37', '2022-07-07 00:45:37'),
(114, '26', 'Chương IV. Bất đẳng thức. Bất phương trình', 'chuong-iv-bat-dang-thuc-bat-phuong-trinh', '2022-07-07 00:45:37', '2022-07-07 00:45:37'),
(115, '25', 'Chương VI. Cung và góc lượng giác. Công thức lượng giác', 'chuong-vi-cung-va-goc-luong-giac-cong-thuc-luong-giac', '2022-07-07 00:46:01', '2022-07-07 00:46:01'),
(116, '26', 'Chương VI. Cung và góc lượng giác. Công thức lượng giác', 'chuong-vi-cung-va-goc-luong-giac-cong-thuc-luong-giac', '2022-07-07 00:46:01', '2022-07-07 00:46:01'),
(117, '25', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:46:12', '2022-07-07 00:46:12'),
(118, '26', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:46:12', '2022-07-07 00:46:12'),
(119, '27', 'Chương I. Vector', 'chuong-i-vector', '2022-07-07 00:48:35', '2022-07-07 00:48:35'),
(120, '28', 'Chương I. Vector', 'chuong-i-vector', '2022-07-07 00:48:35', '2022-07-07 00:48:35'),
(121, '27', 'Chương II. Tích vô hướng của hai vector và ứng dụng', 'chuong-ii-tich-vo-huong-cua-hai-vector-va-ung-dung', '2022-07-07 00:49:03', '2022-07-07 00:49:03'),
(122, '28', 'Chương II. Tích vô hướng của hai vector và ứng dụng', 'chuong-ii-tich-vo-huong-cua-hai-vector-va-ung-dung', '2022-07-07 00:49:03', '2022-07-07 00:49:03'),
(123, '27', 'Chương III. Phương pháp tọa độ trong mặt phẳng', 'chuong-iii-phuong-phap-toa-do-trong-mat-phang', '2022-07-07 00:49:20', '2022-07-07 00:49:20'),
(124, '28', 'Chương III. Phương pháp tọa độ trong mặt phẳng', 'chuong-iii-phuong-phap-toa-do-trong-mat-phang', '2022-07-07 00:49:20', '2022-07-07 00:49:20'),
(125, '27', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:49:30', '2022-07-07 00:49:30'),
(126, '28', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:49:30', '2022-07-07 00:49:30'),
(127, '29', 'Chương I. Hàm số lượng giác và phương trình lượng giác', 'chuong-i-ham-so-luong-giac-va-phuong-trinh-luong-giac', '2022-07-07 00:50:04', '2022-07-07 00:50:04'),
(128, '30', 'Chương I. Hàm số lượng giác và phương trình lượng giác', 'chuong-i-ham-so-luong-giac-va-phuong-trinh-luong-giac', '2022-07-07 00:50:04', '2022-07-07 00:50:04'),
(129, '29', 'Chương II. Tổ hợp - Xác suất', 'chuong-ii-to-hop-xac-suat', '2022-07-07 00:50:25', '2022-07-07 00:50:25'),
(130, '30', 'Chương II. Tổ hợp - Xác suất', 'chuong-ii-to-hop-xac-suat', '2022-07-07 00:50:25', '2022-07-07 00:50:25'),
(131, '29', 'Chương III. Dãy số. Cấp số cộng và cấp số nhân', 'chuong-iii-day-so-cap-so-cong-va-cap-so-nhan', '2022-07-07 00:50:49', '2022-07-07 00:50:49'),
(132, '30', 'Chương III. Dãy số. Cấp số cộng và cấp số nhân', 'chuong-iii-day-so-cap-so-cong-va-cap-so-nhan', '2022-07-07 00:50:49', '2022-07-07 00:50:49'),
(133, '29', 'Chương IV. Giới hạn', 'chuong-iv-gioi-han', '2022-07-07 00:50:59', '2022-07-07 00:50:59'),
(134, '30', 'Chương IV. Giới hạn', 'chuong-iv-gioi-han', '2022-07-07 00:50:59', '2022-07-07 00:50:59'),
(135, '29', 'Chương V. Đạo hàm', 'chuong-v-dao-ham', '2022-07-07 00:51:13', '2022-07-07 00:51:13'),
(136, '30', 'Chương V. Đạo hàm', 'chuong-v-dao-ham', '2022-07-07 00:51:13', '2022-07-07 00:51:13'),
(137, '31', 'Chương I. Phép dời hình và phép đồng dạng trong mặt phẳng', 'chuong-i-phep-doi-hinh-va-phep-dong-dang-trong-mat-phang', '2022-07-07 00:51:46', '2022-07-07 00:51:46'),
(138, '32', 'Chương I. Phép dời hình và phép đồng dạng trong mặt phẳng', 'chuong-i-phep-doi-hinh-va-phep-dong-dang-trong-mat-phang', '2022-07-07 00:51:46', '2022-07-07 00:51:46'),
(139, '31', 'Chương II. Đường thẳng và mặt phẳng trong không gian. Quan hệ song song', 'chuong-ii-duong-thang-va-mat-phang-trong-khong-gian-quan-he-song-song', '2022-07-07 00:52:13', '2022-07-07 00:52:13'),
(140, '32', 'Chương II. Đường thẳng và mặt phẳng trong không gian. Quan hệ song song', 'chuong-ii-duong-thang-va-mat-phang-trong-khong-gian-quan-he-song-song', '2022-07-07 00:52:13', '2022-07-07 00:52:13'),
(141, '31', 'Chương III. Vector trong không gian. Quan hệ vuông góc trong không gian', 'chuong-iii-vector-trong-khong-gian-quan-he-vuong-goc-trong-khong-gian', '2022-07-07 00:52:43', '2022-07-07 00:52:43'),
(142, '32', 'Chương III. Vector trong không gian. Quan hệ vuông góc trong không gian', 'chuong-iii-vector-trong-khong-gian-quan-he-vuong-goc-trong-khong-gian', '2022-07-07 00:52:43', '2022-07-07 00:52:43'),
(143, '33', 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số', 'chuong-i-ung-dung-dao-ham-de-khao-sat-va-ve-do-thi-cua-ham-so', '2022-07-07 00:53:22', '2022-07-07 00:53:22'),
(144, '34', 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số', 'chuong-i-ung-dung-dao-ham-de-khao-sat-va-ve-do-thi-cua-ham-so', '2022-07-07 00:53:22', '2022-07-07 00:53:22'),
(145, '33', 'Chương II. Hàm số lũy thừa hàm số mũ và hàm số logarit', 'chuong-ii-ham-so-luy-thua-ham-so-mu-va-ham-so-logarit', '2022-07-07 00:53:48', '2022-07-07 00:53:48'),
(146, '34', 'Chương II. Hàm số lũy thừa hàm số mũ và hàm số logarit', 'chuong-ii-ham-so-luy-thua-ham-so-mu-va-ham-so-logarit', '2022-07-07 00:53:48', '2022-07-07 00:53:48'),
(147, '33', 'Chương III. Nguyên hàm. Tích phân và ứng dụng', 'chuong-iii-nguyen-ham-tich-phan-va-ung-dung', '2022-07-07 00:54:04', '2022-07-07 00:54:04'),
(148, '34', 'Chương III. Nguyên hàm. Tích phân và ứng dụng', 'chuong-iii-nguyen-ham-tich-phan-va-ung-dung', '2022-07-07 00:54:04', '2022-07-07 00:54:04'),
(149, '33', 'Chướng IV. Số phức', 'chuong-iv-so-phuc', '2022-07-07 00:54:17', '2022-07-07 00:54:17'),
(150, '34', 'Chướng IV. Số phức', 'chuong-iv-so-phuc', '2022-07-07 00:54:17', '2022-07-07 00:54:17'),
(151, '33', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:54:25', '2022-07-07 00:54:25'),
(152, '34', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:54:25', '2022-07-07 00:54:25'),
(153, '35', 'Chương I. Khối đa diện', 'chuong-i-khoi-da-dien', '2022-07-07 00:54:38', '2022-07-07 00:54:38'),
(154, '36', 'Chương I. Khối đa diện', 'chuong-i-khoi-da-dien', '2022-07-07 00:54:38', '2022-07-07 00:54:38'),
(155, '35', 'Chương II. Mặt nón. Mặt trụ. Mặt cầu', 'chuong-ii-mat-non-mat-tru-mat-cau', '2022-07-07 00:55:00', '2022-07-07 00:55:00'),
(156, '36', 'Chương II. Mặt nón. Mặt trụ. Mặt cầu', 'chuong-ii-mat-non-mat-tru-mat-cau', '2022-07-07 00:55:00', '2022-07-07 00:55:00'),
(157, '35', 'Chương III. Phương pháp tọa độ trong không gian', 'chuong-iii-phuong-phap-toa-do-trong-khong-gian', '2022-07-07 00:55:22', '2022-07-07 00:55:22'),
(158, '36', 'Chương III. Phương pháp tọa độ trong không gian', 'chuong-iii-phuong-phap-toa-do-trong-khong-gian', '2022-07-07 00:55:22', '2022-07-07 00:55:22'),
(159, '35', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:55:34', '2022-07-07 00:55:34'),
(160, '36', 'Ôn tập cuối năm', 'on-tap-cuoi-nam', '2022-07-07 00:55:34', '2022-07-07 00:55:34');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id_grade` int(10) UNSIGNED NOT NULL,
  `name_grade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`id_grade`, `name_grade`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Lớp 2', 'lop-2', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(2, 'Lớp 3', 'lop-3', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(3, 'Lớp 4', 'lop-4', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(4, 'Lớp 5', 'lop-5', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(5, 'Lớp 6', 'lop-6', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(6, 'Lớp 7', 'lop-7', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(7, 'Lớp 8', 'lop-8', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(8, 'Lớp 9', 'lop-9', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(9, 'Lớp 10', 'lop-10', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(10, 'Lớp 11', 'lop-11', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(11, 'Lớp 12', 'lop-12', '2022-07-06 23:29:57', '2022-07-06 23:29:57');

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE `lessons` (
  `id_lesson` int(10) UNSIGNED NOT NULL,
  `id_chapter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_lesson` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id_lesson`, `id_chapter`, `name_lesson`, `content`, `page`, `slug`, `created_at`, `updated_at`) VALUES
(1, '1', 'Giải bài 1,2,3 trang 3 SGK Toán 2', 'Giải bài 1,2,3 trang 3 SGK Toán 2...', '3', 'giai-bai-123-trang-3-sgk-toan-2', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(2, '1', 'Giải bài 1,2,3,4,5 trang 4 SGK Toán 2', 'Giải bài 1,2,3,4,5 trang 4 SGK Toán 2...', '4', 'giai-bai-12345-trang-4-sgk-toan-2', '2022-07-06 23:29:57', '2022-07-06 23:29:57');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(3, '2022_07_02_033722_grades_table', 1),
(4, '2022_07_02_033822_subjects_table', 1),
(5, '2022_07_02_033856_chapters_table', 1),
(6, '2022_07_02_033928_lessons_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id_subject` int(10) UNSIGNED NOT NULL,
  `id_grade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id_subject`, `id_grade`, `name_subject`, `slug`, `created_at`, `updated_at`) VALUES
(1, '1', 'Sách giáo khoa Toán', 'sach-giao-khoa-toan', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(2, '1', 'Sách bài tập Toán', 'sach-bai-tap-toan', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(3, '2', 'Sách giáo khoa Toán', 'sach-giao-khoa-toan', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(4, '2', 'Sách bài tập Toán', 'sach-bai-tap-toan', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(5, '3', 'Sách giáo khoa Toán', 'sach-giao-khoa-toan', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(6, '3', 'Sách bài tập Toán', 'sach-bai-tap-toan', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(7, '4', 'Sách giáo khoa Toán', 'sach-giao-khoa-toan', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(8, '4', 'Sách bài tập Toán', 'sach-bai-tap-toan', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(9, '5', 'Sách giáo khoa Toán (Đại số)', 'sach-giao-khoa-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(10, '5', 'Sách bài tập Toán (Đại số)', 'sach-bai-tap-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(11, '5', 'Sách giáo khoa Toán (Hình học)', 'sach-giao-khoa-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(12, '5', 'Sách bài tập Toán (Hình học)', 'sach-bai-tap-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(13, '6', 'Sách giáo khoa Toán (Đại số)', 'sach-giao-khoa-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(14, '6', 'Sách bài tập Toán (Đại số)', 'sach-bai-tap-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(15, '6', 'Sách giáo khoa Toán (Hình học)', 'sach-giao-khoa-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(16, '6', 'Sách bài tập Toán (Hình học)', 'sach-bai-tap-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(17, '7', 'Sách giáo khoa Toán (Đại số)', 'sach-giao-khoa-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(18, '7', 'Sách bài tập Toán (Đại số)', 'sach-bai-tap-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(19, '7', 'Sách giáo khoa Toán (Hình học)', 'sach-giao-khoa-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(20, '7', 'Sách bài tập Toán (Hình học)', 'sach-bai-tap-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(21, '8', 'Sách giáo khoa Toán (Đại số)', 'sach-giao-khoa-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(22, '8', 'Sách bài tập Toán (Đại số)', 'sach-bai-tap-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(23, '8', 'Sách giáo khoa Toán (Hình học)', 'sach-giao-khoa-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(24, '8', 'Sách bài tập Toán (Hình học)', 'sach-bai-tap-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(25, '9', 'Sách giáo khoa Toán (Đại số)', 'sach-giao-khoa-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(26, '9', 'Sách bài tập Toán (Đại số)', 'sach-bai-tap-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(27, '9', 'Sách giáo khoa Toán (Hình học)', 'sach-giao-khoa-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(28, '9', 'Sách bài tập Toán (Hình học)', 'sach-bai-tap-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(29, '10', 'Sách giáo khoa Toán (Đại số)', 'sach-giao-khoa-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(30, '10', 'Sách bài tập Toán (Đại số)', 'sach-bai-tap-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(31, '10', 'Sách giáo khoa Toán (Hình học)', 'sach-giao-khoa-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(32, '10', 'Sách bài tập Toán (Hình học)', 'sach-bai-tap-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(33, '11', 'Sách giáo khoa Toán (Đại số)', 'sach-giao-khoa-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(34, '11', 'Sách bài tập Toán (Đại số)', 'sach-bai-tap-toan-dai-so', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(35, '11', 'Sách giáo khoa Toán (Hình học)', 'sach-giao-khoa-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(36, '11', 'Sách bài tập Toán (Hình học)', 'sach-bai-tap-toan-hinh-hoc', '2022-07-06 23:29:57', '2022-07-06 23:29:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(10) UNSIGNED NOT NULL,
  `name_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `name_user`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', '$2y$10$jh/OtDo/G00XXNWU5czE/eRD6j6Qznwe5uw/gicMYWdpUjFmQ4etS', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(2, 'Phan Văn Bằng', 'pvbang23092002@gmail.com', '$2y$10$Y64f5B1p0iVslhxuxRC05Od26XcvDgm3XPok1vW0cb4cxwdyS5fni', '2022-07-06 23:29:57', '2022-07-06 23:29:57'),
(3, 'Trần Nguyễn Vĩnh Uy', 'uy@gmail.com', '$2y$10$sIzvfDW7r/i.zdQP95wUmuRBZFHPKlR5dyzTmZ89wyWYe20UKlZ6u', '2022-07-06 23:29:57', '2022-07-06 23:29:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chapters`
--
ALTER TABLE `chapters`
  ADD PRIMARY KEY (`id_chapter`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id_grade`);

--
-- Indexes for table `lessons`
--
ALTER TABLE `lessons`
  ADD PRIMARY KEY (`id_lesson`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id_subject`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chapters`
--
ALTER TABLE `chapters`
  MODIFY `id_chapter` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id_grade` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `lessons`
--
ALTER TABLE `lessons`
  MODIFY `id_lesson` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id_subject` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
