

<?php $__env->startSection('admin_content'); ?>
    <div class="card o-hidden border-0 shadow-lg ">
        <div class="card-body p-0">
            <div class="p-5">
                <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Update Chapter (Sửa Chương)</h1>
                </div>
                <br>
                <form class="user" action="/auth/login/admin/chapter/update" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($chapter->id_chapter); ?>" name="id">
                    <div class="form-group">
                        <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dataSubject->id_grade == $grade->id_grade): ?>
                            <input type="text" class="form-control form-control-user" name="name_subject"
                            placeholder="Chọn môn học" list="data2" autocomplete="off" value="<?php echo e($grade->name_grade.' - '.$dataSubject->name_subject); ?>">
                                <?php break; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <datalist id="data2">
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subject->id_grade == $grade->id_grade): ?>
                                        <option value="<?php echo e($grade->name_grade.' - '.$subject->name_subject); ?>">
                                        <?php break; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-user" value="<?php echo e($chapter->name_chapter); ?>" name="name_chapter"
                            placeholder="Tên chương">
                    </div>
                    <br>
                    <button type="submit" class="btn btn-warning btn-user btn-block">
                        Sửa
                    </button>
                    
                </form>
                

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/admin/chapter/update.blade.php ENDPATH**/ ?>