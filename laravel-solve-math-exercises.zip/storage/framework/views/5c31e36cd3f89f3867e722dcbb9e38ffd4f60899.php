<div class="card border border-info shadow-0">
    <div class="card-header text-center bg-info text-white">Bài giải mới nhất</div>

    <ul class="list-group list-group-light list-group-small">
        <?php $__currentLoopData = $rightLessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($lesson->id_chapter == $chapter->id_chapter): ?>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($subject->id_subject == $chapter->id_subject): ?>
                            <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($grade->id_grade == $subject->id_grade): ?>
                                    <li class="list-group-item px-3"><a
                                            href="/<?php echo e($grade->slug); ?>/<?php echo e($subject->slug); ?>/<?php echo e($lesson->slug); ?>"
                                            class="text-black" style="font-size: 15px;"><?php echo e($lesson->name_lesson); ?></a>
                                    </li>
                                    <?php break; ?>
                                    <?php break; ?>
                                    <?php break; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/app/app/right.blade.php ENDPATH**/ ?>