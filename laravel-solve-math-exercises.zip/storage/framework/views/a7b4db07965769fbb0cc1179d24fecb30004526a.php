

<?php $__env->startSection('admin_content'); ?>
    <div class="card o-hidden border-0 shadow-lg ">
        <div class="card-body p-0">
            <div class="p-5">
                <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Update Lesson (Sửa bài)</h1>
                </div>
                <br>
                <form class="user" action="/auth/login/admin/lesson/update" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($lesson->id_lesson); ?>" name="id">
                    <div class="form-group">
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dataChapter->id_subject == $subject->id_subject): ?>
                                <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($subject->id_grade == $grade->id_grade): ?>
                                        <input type="text" class="form-control form-control-user" name="name_chapter"
                                            placeholder="Chọn chương" list="data" autocomplete="off"
                                            value="<?php echo e($grade->name_grade . ' - ' . $subject->name_subject . ' - ' . $dataChapter->name_chapter); ?>">
                                        <?php break; ?>
                                        <?php break; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <datalist id="data">
                            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($chapter->id_subject == $subject->id_subject): ?>
                                        <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($subject->id_grade == $grade->id_grade): ?>
                                                <option
                                                    value="<?php echo e($grade->name_grade . ' - ' . $subject->name_subject . ' - ' . $chapter->name_chapter); ?>">
                                                <?php break; ?>
                                                <?php break; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-user" value="<?php echo e($lesson->name_lesson); ?>"
                            name="name_lesson" placeholder="Tên bài">
                    </div>

                    <span class="mb-4" style="margin: 10px;">Nội dung:</span>
                    
                    <textarea id="mytextarea" name="content"><?php echo e($lesson->content); ?></textarea>

                    <br>
                    <div class="form-group">
                        <input type="text" class="form-control form-control-user" name="page" placeholder="Trang"
                            value="<?php echo e($lesson->page); ?>">
                    </div>

                    <br>
                    <button type="submit" class="btn btn-warning btn-user btn-block">
                        Sửa
                    </button>

                </form>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/admin/lesson/update.blade.php ENDPATH**/ ?>