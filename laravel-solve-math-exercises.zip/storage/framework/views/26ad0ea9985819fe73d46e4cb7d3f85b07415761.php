<div class="row">
    <?php $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card border border-info shadow-0">
                <a href="/<?php echo e($grade->slug); ?>" class="card-header text-center bg-info text-white"><?php echo e($grade->name_grade); ?></a>
            
                <ul class="list-group list-group-light list-group-small">
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($subject->id_grade == $grade->id_grade): ?>
                            <li class="list-group-item px-3"><a href="/<?php echo e($grade->slug); ?>/<?php echo e($subject->slug); ?>" class="text-black" style="font-size: 15px;"><?php echo e($subject->name_subject); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
            </div>
            <br>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/app/app/body.blade.php ENDPATH**/ ?>