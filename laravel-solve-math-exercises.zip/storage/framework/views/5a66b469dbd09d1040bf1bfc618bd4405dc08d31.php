<?php $__env->startSection('admin_content'); ?>
    <?php switch($route):
        
        case ('template.dashboard'): ?>
            <?php echo $__env->make('admin.app.template.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.404'): ?>
            <?php echo $__env->make('admin.app.template.404', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.buttons'): ?>
            <?php echo $__env->make('admin.app.template.buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.cards'): ?>
            <?php echo $__env->make('admin.app.template.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.charts'): ?>
            <?php echo $__env->make('admin.app.template.charts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.forgot-password'): ?>
            <?php echo $__env->make('admin.app.template.forgot-password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.login'): ?>
            <?php echo $__env->make('admin.app.template.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.register'): ?>
            <?php echo $__env->make('admin.app.template.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.tables'): ?>
            <?php echo $__env->make('admin.app.template.tables', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.utilities-animation'): ?>
            <?php echo $__env->make('admin.app.template.utilities-animation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.utilities-border'): ?>
            <?php echo $__env->make('admin.app.template.utilities-border', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.utilities-color'): ?>
            <?php echo $__env->make('admin.app.template.utilities-color', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('template.utilities-other'): ?>
            <?php echo $__env->make('admin.app.template.utilities-other', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php default: ?>
            <?php echo $__env->make('admin.app.template.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endswitch; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.template.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/admin/app/template/index.blade.php ENDPATH**/ ?>