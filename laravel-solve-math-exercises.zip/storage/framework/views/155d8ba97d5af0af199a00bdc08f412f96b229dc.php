

<?php $__env->startSection('admin_content'); ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between shadow-0">
            <h6 class="m-0 font-weight-bold text-primary">LESSON ( BÀI HỌC )</h6>
            <div class="dropdown no-arrow">
                <a class="dropdown-toggle btn btn-primary" href="/auth/login/admin/lesson/add" role="button">
                    Thêm
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Chương</th>
                            <th>Bài</th>
                            <th>Nội dung</th>
                            <th>Thay đổi</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>ID</th>
                            <th>Chương</th>
                            <th>Bài</th>
                            <th>Nội dung</th>
                            <th>Thay đổi</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($lesson->id_lesson); ?></td>
                                <td>
                                    <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($chapter->id_chapter == $lesson->id_chapter): ?>
                                            <?php echo e($chapter->name_chapter); ?>

                                            <?php break; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </td>
                                <td><?php echo e($lesson->name_lesson); ?></td>
                                <td><?php echo $lesson->content; ?></td>
                                <td>
                                    <a href="/auth/login/admin/lesson/update/id=<?php echo e($lesson->id_lesson); ?>" type="button" class="btn btn-warning">Sửa</a>
                                    <a href="/auth/login/admin/lesson/delete/id=<?php echo e($lesson->id_lesson); ?>" onclick="return confirm('Bạn có thật sự muốn xóa ?');" type="button"
                                        class="btn btn-danger">Xóa</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/admin/lesson/index.blade.php ENDPATH**/ ?>