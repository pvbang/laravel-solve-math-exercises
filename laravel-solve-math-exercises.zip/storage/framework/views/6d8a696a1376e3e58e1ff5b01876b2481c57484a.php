<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/" class="text-black">Trang chủ</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($dataGrade->name_grade); ?></li>
    </ol>
</nav>

<div class="row">
    <?php $__currentLoopData = $dataSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataSubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
            <div class="card border border-info shadow-0">
                <a href="/<?php echo e($dataGrade->slug); ?>/<?php echo e($dataSubject->slug); ?>"
                    class="card-header text-center bg-info text-white text-uppercase"><?php echo e($dataSubject->name_subject); ?></a>

                <ul class="list-group list-group-light list-group-small">
                    <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($chapter->id_subject == $dataSubject->id_subject): ?>
                            <li class="list-group-item px-3"><a
                                    href="/<?php echo e($dataGrade->slug); ?>/<?php echo e($dataSubject->slug); ?>#<?php echo e($chapter->slug); ?>"
                                    class="text-black" style="font-size: 15px;"><?php echo e($chapter->name_chapter); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <br>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/app/grade/index.blade.php ENDPATH**/ ?>