<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/" class="text-black">Trang chủ</a></li>
        <li class="breadcrumb-item"><a href="/<?php echo e($dataGrade->slug); ?>" class="text-black"><?php echo e($dataGrade->name_grade); ?></a></li>
        <li class="breadcrumb-item"><a href="/<?php echo e($dataGrade->slug); ?>/<?php echo e($dataSubject->slug); ?>"
                class="text-black"><?php echo e($dataSubject->name_subject); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($dataLesson->name_lesson); ?></li>
    </ol>
</nav>

<div class="card border border-info shadow-0" style="margin-bottom: 10px">
    <div class="card-header text-center text-uppercase text-info"><b><?php echo e($dataLesson->name_lesson); ?></b></div>
    <div class="card-body">
        <?php echo $dataLesson->content; ?>

    </div>
    <div class="card-footer text-muted text-center">Ngày cập nhật: <?php echo e(date('d/m/Y', strtotime($dataLesson->updated_at))); ?></div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/app/lesson/index.blade.php ENDPATH**/ ?>