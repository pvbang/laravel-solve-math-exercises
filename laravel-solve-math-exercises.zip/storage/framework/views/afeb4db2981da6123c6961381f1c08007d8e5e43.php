

<?php $__env->startSection('content'); ?>
    <?php switch($route):
        case ('index'): ?>
            <?php echo $__env->make('app.app.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('grade'): ?>
            <?php echo $__env->make('app.grade.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('subject'): ?>
            <div class="row">
                <div class="col-md-8">
                    <?php echo $__env->make('app.subject.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('app.app.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        <?php break; ?>

        <?php case ('lesson'): ?>
            <div class="row">
                <div class="col-md-8">
                    <?php echo $__env->make('app.lesson.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('app.app.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        <?php break; ?>

        <?php default: ?>
            <?php echo $__env->make('app.app.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endswitch; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.app.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/app/index.blade.php ENDPATH**/ ?>