<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/" class="text-black">Trang chủ</a></li>
        <li class="breadcrumb-item"><a href="/<?php echo e($dataGrade->slug); ?>" class="text-black"><?php echo e($dataGrade->name_grade); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($dataSubject->name_subject); ?></li>
    </ol>
</nav>
<?php
$count = 0;
?>
<div class="accordion" id="accordionPanelsStayOpenExample">
    <?php $__currentLoopData = $dataChapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($count == 0): ?>
            <div class="accordion-item" id="<?php echo e($chapter->slug); ?>">
                <h2 class="accordion-header" id="headingOne">
                    <button class="accordion-button text-black fw-bolder text-uppercase" type="button" data-mdb-toggle="collapse"
                        data-mdb-target="#slug<?php echo e($chapter->id_chapter); ?>" aria-expanded="true"
                        aria-controls="panelsStayOpen-collapseOne">
                        <?php echo e($chapter->name_chapter); ?>

                    </button>
                </h2>
                <div id="slug<?php echo e($chapter->id_chapter); ?>" class="accordion-collapse collapse show"
                    aria-labelledby="headingOne">
                    <div class="accordion-body">
                        <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($lesson->id_chapter == $chapter->id_chapter): ?>
                                <a href="/<?php echo e($dataGrade->slug); ?>/<?php echo e($dataSubject->slug); ?>/<?php echo e($lesson->slug); ?>"
                                    class="text-black" style="font-size: 15px;"><?php echo e($lesson->name_lesson); ?></a><br>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="accordion-item" id="<?php echo e($chapter->slug); ?>">
                <h2 class="accordion-header" id="headingOne">
                    <button class="accordion-button text-black fw-bolder text-uppercase" type="button" data-mdb-toggle="collapse"
                        data-mdb-target="#slug<?php echo e($chapter->id_chapter); ?>" aria-expanded="true"
                        aria-controls="panelsStayOpen-collapseOne">
                        <?php echo e($chapter->name_chapter); ?>

                    </button>
                </h2>
                <div id="slug<?php echo e($chapter->id_chapter); ?>" class="accordion-collapse collapse"
                    aria-labelledby="headingOne">
                    <div class="accordion-body">
                        <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($lesson->id_chapter == $chapter->id_chapter): ?>
                                <a href="/<?php echo e($dataGrade->slug); ?>/<?php echo e($dataSubject->slug); ?>/<?php echo e($lesson->slug); ?>"
                                    class="text-black" style="font-size: 15px;"><?php echo e($lesson->name_lesson); ?></a><br>
                                
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php
            $count = 1;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH C:\xampp\htdocs\laravel-solve-math-exercises\resources\views/app/subject/index.blade.php ENDPATH**/ ?>